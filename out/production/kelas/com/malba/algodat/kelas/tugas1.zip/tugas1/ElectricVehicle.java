package com.malba.algodat.kelas.tugas1;

public interface ElectricVehicle {
    String E_PREFIX = "the Electric";
    void charge();
}
