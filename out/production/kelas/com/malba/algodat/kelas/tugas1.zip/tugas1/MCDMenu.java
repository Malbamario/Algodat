package com.malba.algodat.kelas.tugas1;

public class MCDMenu {
    String name;
    int price;

    MCDMenu(String name, int price){
        this.name = name;
        this.price = price;
    }
}
